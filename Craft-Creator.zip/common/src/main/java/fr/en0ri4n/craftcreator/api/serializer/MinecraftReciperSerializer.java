package fr.en0ri4n.craftcreator.api.serializer;

public class MinecraftReciperSerializer
{
}
