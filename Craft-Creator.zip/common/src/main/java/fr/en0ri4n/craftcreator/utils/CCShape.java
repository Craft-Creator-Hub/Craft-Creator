package fr.en0ri4n.craftcreator.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CCShape
{
    private final double x1, y1, z1, x2, y2, z3;
}
