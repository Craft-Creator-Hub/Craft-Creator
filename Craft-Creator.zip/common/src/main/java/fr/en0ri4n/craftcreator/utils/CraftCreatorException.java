package fr.en0ri4n.craftcreator.utils;

public class CraftCreatorException extends Exception
{
    public CraftCreatorException(String message)
    {
        super(message);
    }
}
