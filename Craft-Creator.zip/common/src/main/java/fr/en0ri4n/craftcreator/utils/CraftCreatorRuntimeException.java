package fr.en0ri4n.craftcreator.utils;

public class CraftCreatorRuntimeException extends RuntimeException
{
    public CraftCreatorRuntimeException(String message)
    {
        super(message);
    }
}
