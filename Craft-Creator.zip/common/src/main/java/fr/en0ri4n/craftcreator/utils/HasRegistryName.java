package fr.en0ri4n.craftcreator.utils;

public interface HasRegistryName
{
    Identifier getRegistryName();
}
