package fr.en0ri4n.craftcreator.utils;

public enum SerializerFunction
{
    ADD,
    REMOVE,
    REMOVE_ADDED,
    UPDATE
}