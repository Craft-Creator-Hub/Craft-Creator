package fr.en0ri4n.craftcreator.utils;

public enum SerializerType
{
    MINECRAFT_DATAPACK,
    KUBE_JS,
    CRAFT_TWEAKER,
}