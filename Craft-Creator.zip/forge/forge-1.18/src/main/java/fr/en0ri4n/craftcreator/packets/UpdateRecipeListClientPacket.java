package fr.en0ri4n.craftcreator.packets;

import fr.en0ri4n.craftcreator.api.ClientUtils;
import fr.en0ri4n.craftcreator.base.SupportedMods;
import fr.en0ri4n.craftcreator.init.InitPackets;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class UpdateRecipeListClientPacket
{
    private final SupportedMods mod;
    private final InitPackets.RecipeList recipeList;
    private final String recipeId;
    private final String serializedRecipe;

    public UpdateRecipeListClientPacket(SupportedMods mod, InitPackets.RecipeList recipeList, String recipeId, String serializedRecipe)
    {
        this.mod = mod;
        this.recipeList = recipeList;
        this.recipeId = recipeId;
        this.serializedRecipe = serializedRecipe;
    }

    public static void encode(UpdateRecipeListClientPacket msg, FriendlyByteBuf packetBuffer)
    {
        packetBuffer.writeEnum(msg.mod);
        packetBuffer.writeEnum(msg.recipeList);
        packetBuffer.writeUtf(msg.recipeId);
        packetBuffer.writeUtf(msg.serializedRecipe);
    }

    public static UpdateRecipeListClientPacket decode(FriendlyByteBuf packetBuffer)
    {
        SupportedMods mod = packetBuffer.readEnum(SupportedMods.class);
        InitPackets.RecipeList recipeList = packetBuffer.readEnum(InitPackets.RecipeList.class);
        String recipeId = packetBuffer.readUtf();
        String serializedRecipe = packetBuffer.readUtf();

        return new UpdateRecipeListClientPacket(mod, recipeList, recipeId, serializedRecipe);
    }

    public static class ClientHandler
    {
        public static void handle(UpdateRecipeListClientPacket msg, Supplier<NetworkEvent.Context> ctx)
        {
            ClientUtils.addToList(msg.recipeList, msg.recipeId, msg.serializedRecipe);
            ctx.get().setPacketHandled(true);
        }
    }
}
