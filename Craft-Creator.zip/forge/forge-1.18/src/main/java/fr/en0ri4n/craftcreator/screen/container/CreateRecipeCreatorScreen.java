package fr.en0ri4n.craftcreator.screen.container;

import com.google.gson.JsonObject;
import com.mojang.blaze3d.vertex.PoseStack;
import fr.en0ri4n.craftcreator.References;
import fr.en0ri4n.craftcreator.base.ModRecipeCreators;
import fr.en0ri4n.craftcreator.container.CreateRecipeCreatorContainer;
import fr.en0ri4n.craftcreator.container.slot.utils.PositionnedSlot;
import fr.en0ri4n.craftcreator.recipes.utils.RecipeInfos;
import fr.en0ri4n.craftcreator.screen.container.base.MultiScreenModRecipeCreatorScreen;
import fr.en0ri4n.craftcreator.screen.widgets.RecipeEntryWidget;
import fr.en0ri4n.craftcreator.utils.PairValues;
import fr.en0ri4n.craftcreator.utils.SlotHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.world.entity.player.Inventory;

import java.util.ArrayList;
import java.util.List;

public class CreateRecipeCreatorScreen extends MultiScreenModRecipeCreatorScreen<CreateRecipeCreatorContainer>
{
    private RecipeEntryWidget inputWidget;
    private RecipeEntryWidget outputWidget;
    private final BlockPos tilePos;

    public CreateRecipeCreatorScreen(CreateRecipeCreatorContainer screenContainer, Inventory inv, Component titleIn)
    {
        super(screenContainer, inv, titleIn, screenContainer.getTile().getBlockPos());
        this.tilePos = screenContainer.getTile().getBlockPos();
        this.guiTextureSize = 256;
        this.imageWidth = 256;
        this.imageHeight = 256;
    }

    @Override
    protected void initFields()
    {
        addNumberField(0, 0, 90, 100, 1);
    }

    @Override
    protected void initWidgets()
    {
        int gapX = 10;
        int gapY = 22;
        int widgetHeight = 110;
        int widgetWidth = imageWidth / 2 - 2 * gapX;

        inputWidget = new RecipeEntryWidget(getCurrentRecipe(), tilePos,  leftPos + gapX, topPos + gapY, widgetWidth, widgetHeight, false, -1);
        outputWidget = new RecipeEntryWidget(getCurrentRecipe(), tilePos, leftPos + guiTextureSize - gapX - widgetWidth, topPos + gapY, widgetWidth, widgetHeight, true, -1);
    }

    @Override
    protected void retrieveExtraData()
    {

    }

    @Override
    protected RecipeInfos getExtraRecipeInfos(RecipeInfos recipeInfos)
    {
        recipeInfos.addParameter(new RecipeInfos.RecipeParameterNumber("processing_time", getDataField(0).getIntValue(), false));
        return recipeInfos;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void setData(String dataName, Object data)
    {
        super.setData(dataName, data);

        if(dataName.startsWith("inputs"))
        {
            PairValues<String, List<JsonObject>> inputs = (PairValues<String, List<JsonObject>>) data;
            if(inputs.getFirstValue().equals(getCurrentRecipe().getRecipeTypeLocation().getPath()))
                inputWidget.setEntries(inputs.getSecondValue());
        }
        else if(dataName.startsWith("outputs"))
        {
            PairValues<String, List<JsonObject>> outputs = (PairValues<String, List<JsonObject>>) data;
            if(outputs.getFirstValue().equals(getCurrentRecipe().getRecipeTypeLocation().getPath()))
                outputWidget.setEntries(outputs.getSecondValue());
        }
    }

    @Override
    protected void updateGui()
    {
        inputWidget.refresh(getCurrentRecipe());
        outputWidget.refresh(getCurrentRecipe());
        inputWidget.setMaxSize(getCurrentRecipe().getMaxInputSize());
        outputWidget.setMaxSize(getCurrentRecipe().getMaxOutputSize());
        setExecuteButtonPos(this.leftPos + this.imageWidth / 2 - 21, this.topPos + this.imageHeight / 2 + 8);

        if(getCurrentRecipe().is(ModRecipeCreators.CRUSHING, ModRecipeCreators.CUTTING))
        {
            showDataField(0);
            setDataFieldValue(100, false, 0);
            setDataFieldPos(0, leftPos + 10, topPos + imageHeight / 2 + 20);

            inputWidget.setHasCount(false);
            inputWidget.setHasChance(false);
            outputWidget.setHasTag(false);
        }
    }

    @Override
    protected void renderGui(PoseStack matrixStack, int mouseX, int mouseY, float partialTicks)
    {
        if(getCurrentRecipe().is(ModRecipeCreators.CRUSHING, ModRecipeCreators.CUTTING))
        {
            renderDataFieldTitle(0, new TextComponent("Processing Time :"), matrixStack);
        }

        if(inputWidget != null)
            inputWidget.render(matrixStack, mouseX, mouseY, partialTicks);
        if(outputWidget != null)
            outputWidget.render(matrixStack, mouseX, mouseY, partialTicks);
        if(outputWidget != null)
            outputWidget.renderDropdown(matrixStack, mouseX, mouseY, partialTicks);
        if(inputWidget != null)
            inputWidget.renderDropdown(matrixStack, mouseX, mouseY, partialTicks);
    }

    @Override
    protected void renderLabels(PoseStack matrixStack, int pMouseX, int pMouseY)
    {
        super.renderLabels(matrixStack, pMouseX, pMouseY);
        renderSideTitles(matrixStack);
    }

    @Override
    protected void renderSideTitles(PoseStack matrixStack)
    {
        // Render Labels
        MutableComponent inputLabel = References.getTranslate("screen.recipe_creator.label.input_counter", ChatFormatting.GRAY + String.valueOf(getCurrentRecipe().getMaxInputSize() == -1 ? "∞" : getCurrentRecipe().getMaxInputSize()));
        MutableComponent ouputLabel = References.getTranslate("screen.recipe_creator.label.output_counter", ChatFormatting.GRAY + String.valueOf(getCurrentRecipe().getMaxOutputSize() == -1 ? "∞" : getCurrentRecipe().getMaxOutputSize()));
        Screen.drawString(matrixStack, this.font, inputLabel, this.imageWidth / 4 - font.width(inputLabel.getString()) / 2, 8, 0xFFFFFFFF);
        Screen.drawString(matrixStack, this.font, ouputLabel, this.imageWidth / 4 * 3 - font.width(ouputLabel.getString()) / 2, 8, 0xFFFFFFFF);
    }

    @Override
    public int getArrowXPos(boolean right)
    {
        return right ? super.getArrowXPos(true) - 40 : super.getArrowXPos(false) + 40;
    }

    @Override
    protected List<PositionnedSlot> getTaggableSlots()
    {
        return SlotHelper.CREATE_SLOTS_INPUT;
    }

    @Override
    protected List<PositionnedSlot> getNbtTaggableSlots()
    {
        return new ArrayList<>();
    }

    @Override
    public void containerTick()
    {
        if(inputWidget != null)
        {
            outputWidget.setCanUseWidget(!inputWidget.isFocused());
            inputWidget.tick();
        }

        if(outputWidget != null)
        {
            inputWidget.setCanUseWidget(!outputWidget.isFocused());
            outputWidget.tick();
        }
    }

    @Override
    protected void renderTooltip(PoseStack poseStack, int mouseX, int mouseY)
    {
        if(inputWidget != null)
            inputWidget.renderTooltip(poseStack, mouseX, mouseY, width, height);
        if(outputWidget != null)
            outputWidget.renderTooltip(poseStack, mouseX, mouseY, width, height);

        if(inputWidget != null && outputWidget != null)
            if(!inputWidget.isFocused() && !outputWidget.isFocused())
                super.renderTooltip(poseStack, mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        if(!inputWidget.isFocused() && !outputWidget.isFocused()) super.mouseClicked(mouseX, mouseY, button);
        inputWidget.mouseClicked(mouseX, mouseY, button);
        outputWidget.mouseClicked(mouseX, mouseY, button);
        return true;
    }

    @Override
    public boolean mouseDragged(double pMouseX, double pMouseY, int pButton, double pDragX, double pDragY)
    {
        super.mouseDragged(pMouseX, pMouseY, pButton, pDragX, pDragY);
        inputWidget.mouseDragged(pMouseX, pMouseY, pButton, pDragX, pDragY);
        outputWidget.mouseDragged(pMouseX, pMouseY, pButton, pDragX, pDragY);
        return true;
    }

    @Override
    public boolean mouseScrolled(double pMouseX, double pMouseY, double pDelta)
    {
        super.mouseScrolled(pMouseX, pMouseY, pDelta);
        inputWidget.mouseScrolled(pMouseX, pMouseY, pDelta);
        outputWidget.mouseScrolled(pMouseX, pMouseY, pDelta);
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers)
    {
        if(!inputWidget.isFocused() && !outputWidget.isFocused()) return super.keyPressed(keyCode, scanCode, modifiers);
        inputWidget.keyPressed(keyCode, scanCode, modifiers);
        outputWidget.keyPressed(keyCode, scanCode, modifiers);
        return true;
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers)
    {
        if(!inputWidget.isFocused() && !outputWidget.isFocused()) return super.charTyped(codePoint, modifiers);
        inputWidget.charTyped(codePoint, modifiers);
        outputWidget.charTyped(codePoint, modifiers);
        return true;
    }
}
