package fr.en0ri4n.craftcreator.screen.container.base;


import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;

public abstract class ModRecipeCreatorDataScreen<T extends AbstractContainerMenu> extends AbstractContainerScreen<T>
{
    public ModRecipeCreatorDataScreen(T p_97741_, Inventory p_97742_, Component p_97743_)
    {
        super(p_97741_, p_97742_, p_97743_);
    }

    public abstract void setData(String dataName, Object data);
}
