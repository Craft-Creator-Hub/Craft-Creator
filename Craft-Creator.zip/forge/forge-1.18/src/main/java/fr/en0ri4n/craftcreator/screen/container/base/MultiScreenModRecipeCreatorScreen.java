package fr.en0ri4n.craftcreator.screen.container.base;

import com.mojang.blaze3d.vertex.PoseStack;
import fr.en0ri4n.craftcreator.References;
import fr.en0ri4n.craftcreator.api.ClientUtils;
import fr.en0ri4n.craftcreator.base.ModRecipeCreators;
import fr.en0ri4n.craftcreator.base.RecipeCreator;
import fr.en0ri4n.craftcreator.base.SupportedMods;
import fr.en0ri4n.craftcreator.container.base.CommonContainer;
import fr.en0ri4n.craftcreator.container.slot.SimpleSlotItemHandler;
import fr.en0ri4n.craftcreator.container.slot.utils.PositionnedSlot;
import fr.en0ri4n.craftcreator.init.InitPackets;
import fr.en0ri4n.craftcreator.packets.CreateRecipePacket;
import fr.en0ri4n.craftcreator.packets.RetrieveRecipeCreatorTileDataServerPacket;
import fr.en0ri4n.craftcreator.packets.UpdateRecipeCreatorTileDataServerPacket;
import fr.en0ri4n.craftcreator.recipes.base.ModRecipeSerializer;
import fr.en0ri4n.craftcreator.recipes.utils.RecipeInfos;
import fr.en0ri4n.craftcreator.screen.widgets.ButtonGrid;
import fr.en0ri4n.craftcreator.screen.widgets.NumberDataFieldWidget;
import fr.en0ri4n.craftcreator.screen.widgets.buttons.ExecuteButton;
import fr.en0ri4n.craftcreator.screen.widgets.buttons.ItemIconButton;
import fr.en0ri4n.craftcreator.screen.widgets.buttons.SimpleButton;
import fr.en0ri4n.craftcreator.screen.widgets.buttons.SimpleCheckBox;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class MultiScreenModRecipeCreatorScreen<T extends CommonContainer> extends TaggeableSlotsContainerScreen<T>
{
    protected int guiTextureSize = 256;

    private final BlockPos tilePos;

    // Only to check if it's a vanilla machine
    protected boolean isVanillaScreen;
    private SimpleCheckBox isKubeJSRecipeButton;

    protected ExecuteButton executeButton;
    protected SimpleButton nextButton;
    protected SimpleButton previousButton;

    protected ButtonGrid<ItemIconButton> buttonGrid;
    protected ItemIconButton recipeTypeButton;

    protected final List<NumberDataFieldWidget> dataFields;

    protected int currentScreenIndex;

    public MultiScreenModRecipeCreatorScreen(T screenContainer, Inventory inv, Component titleIn, BlockPos pos)
    {
        super(screenContainer, inv, titleIn, pos);
        this.tilePos = screenContainer.getTile().getBlockPos();
        this.dataFields = new ArrayList<>();
        this.currentScreenIndex = 0;
    }

    @Override
    protected void init()
    {
        super.init();

        initFields();

        this.buttonGrid = new ButtonGrid<>(this.leftPos + this.imageWidth, this.topPos, 20, 2, 4, ItemIconButton.getButtons(getAvailableRecipesCreator().stream().map(RecipeCreator::getRecipeIcon).collect(Collectors.toList())), (button) ->
        {
            this.currentScreenIndex = this.buttonGrid.getButtons().indexOf(button);
            updateData();
            updateScreen();

            this.recipeTypeButton.setItem(button.getItem());
        });

        addRenderableWidget(this.recipeTypeButton = new ItemIconButton(this.leftPos + imageWidth - 20, this.topPos, ItemStack.EMPTY, button -> this.buttonGrid.setVisible(!this.buttonGrid.isVisible())));

        if(isVanillaScreen)
        {
            InitPackets.NetworkHelper.sendToServer(new RetrieveRecipeCreatorTileDataServerPacket("kubejs_recipe", this.getMenu().getTile().getBlockPos(), InitPackets.PacketDataType.BOOLEAN));
            this.addRenderableWidget(isKubeJSRecipeButton = new SimpleCheckBox(leftPos, topPos + imageHeight + 2, 10, 10, References.getTranslate("screen.recipe_creator_screen.kube_js_button"), false));
            if(!SupportedMods.isKubeJSLoaded())
            {
                isKubeJSRecipeButton.visible = false;
                isKubeJSRecipeButton.setSelected(false);
            }
        }

        this.addRenderableWidget(executeButton = new ExecuteButton(this.leftPos + this.imageWidth / 2 - 20, this.topPos + 35, 42, (button) -> sendRecipe()));

        this.addRenderableWidget(nextButton = new SimpleButton(References.getTranslate("screen.recipe_creator.button.next"), getArrowXPos(true), this.topPos + this.imageHeight - 66, 10, 20, (button) -> nextPage()));
        this.addRenderableWidget(previousButton = new SimpleButton(References.getTranslate("screen.recipe_creator.button.previous"), getArrowXPos(false), this.topPos + this.imageHeight - 66, 10, 20, (button) -> previousPage()));

        initWidgets();
        retrieveData();

        updateScreen();
    }

    private void sendRecipe()
    {
        InitPackets.NetworkHelper.sendToServer(new CreateRecipePacket(this.getMenu().getMod(), getCurrentRecipe(), this.tilePos, getRecipeInfos(RecipeInfos.create()), getCurrentSerializerType()));
    }

    /**
     * Called before retrieving data from server, used to init fields
     */
    protected abstract void initFields();

    /**
     * Called to init widgets
     */
    protected abstract void initWidgets();

    /**
     * Called to retrieve data from server<br>
     * Override {@link #retrieveExtraData()} to retrieve other datas
     */
    private void retrieveData()
    {
        // Retrieve data from server
        InitPackets.NetworkHelper.sendToServer(new RetrieveRecipeCreatorTileDataServerPacket("screen_index", this.getMenu().getTile().getBlockPos(), InitPackets.PacketDataType.INT));
        InitPackets.NetworkHelper.sendToServer(new RetrieveRecipeCreatorTileDataServerPacket("recipe_type", this.getMenu().getTile().getBlockPos(), InitPackets.PacketDataType.STRING));
        InitPackets.NetworkHelper.sendToServer(new RetrieveRecipeCreatorTileDataServerPacket("fields", this.getMenu().getTile().getBlockPos(), InitPackets.PacketDataType.DOUBLE_ARRAY));
        retrieveExtraData();
    }

    /**
     * Used to retrieve extra data from server (called after {@link #initFields()} and {@link #initWidgets()})
     */
    protected abstract void retrieveExtraData();

    protected ModRecipeSerializer.SerializerType getCurrentSerializerType()
    {
        if(isVanillaScreen && !isKubeJSRecipeButton.selected() || !SupportedMods.isKubeJSLoaded()) return ModRecipeSerializer.SerializerType.MINECRAFT_DATAPACK;

        return ModRecipeSerializer.SerializerType.KUBE_JS;
    }

    @Override
    public void setData(String dataName, Object data)
    {
        super.setData(dataName, data);

        if(dataName.equals("screen_index")) this.setCurrentScreenIndex((Integer) data);
        else if(dataName.equals("kubejs_recipe") && isVanillaScreen) this.isKubeJSRecipeButton.setSelected((boolean) data);
        else if(dataName.equals("fields")) this.setFields((double[]) data);
    }

    private void setFields(double[] data)
    {
        for(int i = 0; i < data.length; i++)
        {
            if(i >= this.dataFields.size()) break;

            setDataFieldValue(data[i], getDataField(i).isDouble(), i);
        }
    }

    private double[] getFields()
    {
        return this.dataFields.stream().map(NumberDataFieldWidget::getValue).mapToDouble(str -> str.isEmpty() ? 1D : Double.parseDouble(str)).toArray();
    }

    public List<Rect2i> getExtraAreas()
    {
        List<Rect2i> areas = new ArrayList<>();
        if(guiTagList != null) areas.add(guiTagList.getArea());
        if(buttonGrid != null) areas.add(buttonGrid.getArea());
        if(previousButton != null) areas.add(previousButton.getArea());
        if(nextButton != null) areas.add(nextButton.getArea());
        return areas;
    }

    public int getArrowXPos(boolean right)
    {
        return right ? this.leftPos + this.imageWidth + 3 : this.leftPos - 3 - 10;
    }

    private RecipeInfos getRecipeInfos(RecipeInfos recipeInfos)
    {
        recipeInfos.addParameter(new RecipeInfos.RecipeParameterMap(RecipeInfos.Parameters.TAGGED_SLOTS, this.getTagged()));
        recipeInfos.addParameter(new RecipeInfos.RecipeParameterIntList(RecipeInfos.Parameters.NBT_SLOTS, this.nbtSlots));
        if(isVanillaScreen) recipeInfos.addParameter(new RecipeInfos.RecipeParameterBoolean(RecipeInfos.Parameters.KUBEJS_RECIPE, this.isKubeJSRecipeButton.selected() && SupportedMods.isKubeJSLoaded()));
        return getExtraRecipeInfos(recipeInfos);
    }

    protected abstract RecipeInfos getExtraRecipeInfos(RecipeInfos recipeInfos);

    private Map<Integer, ResourceLocation> getTagged()
    {
        Map<Integer, ResourceLocation> map = new HashMap<>();

        this.getTaggedSlots().forEach((slot, loc) -> map.put(slot.getSlotIndex(), loc));

        return map;
    }

    /**
     * This method is called when the screen change.<br>
     * To Override to perform changes between screens.
     */
    private void updateScreen()
    {
        hideDataFields();
        this.updateSlots();

        nextButton.visible = hasNext();
        previousButton.visible = hasPrevious();

        this.recipeTypeButton.setItem(getCurrentRecipe().getRecipeIcon());

        updateGui();
    }

    protected abstract void updateGui();

    protected void hideDataFields()
    {
        this.dataFields.forEach(textField -> textField.active = textField.visible = false);
    }

    protected void showDataField(int... index)
    {
        for(int i : index)
        {
            this.dataFields.get(i).active = this.dataFields.get(i).visible = true;
        }
    }

    protected void setDataFieldValue(Number defaultValue, boolean isDouble, int... index)
    {
        for(int i : index)
        {
            this.dataFields.get(i).setNumberValue(defaultValue, isDouble);
        }
    }

    public void setCurrentScreenIndex(int index)
    {
        this.currentScreenIndex = index;
        updateScreen();
    }

    protected void setDataFieldPos(int index, int x, int y)
    {
        dataFields.get(index).x = x;
        dataFields.get(index).y = y;
    }

    protected void setDataFieldSize(int index, int width)
    {
        dataFields.get(index).setWidth(width);
        dataFields.get(index).setHeight(16);
    }

    protected void setDataFieldPosAndSize(int index, int x, int y, int width)
    {
        setDataFieldPos(index, x, y);
        setDataFieldSize(index, width);
    }

    protected void setDataField(int index, int x, int y, int width, Number value, boolean isDouble)
    {
        setDataFieldPosAndSize(index, x, y, width);
        setDataFieldValue(value, isDouble, index);
    }

    protected void setDataFieldTooltip(int index, MutableComponent tooltip)
    {
        getDataField(index).setTooltip(tooltip);
    }

    protected void setExecuteButtonPos(int x, int y)
    {
        executeButton.x = x;
        executeButton.y = y;
    }

    protected void setExecuteButtonPosAndSize(int x, int y, int width)
    {
        setExecuteButtonPos(x, y);
        setExecuteButtonWidth(width);
    }

    protected void setExecuteButtonWidth(int width)
    {
        executeButton.setWidth(width);
    }

    protected RecipeCreator getCurrentRecipe()
    {
        return getAvailableRecipesCreator().get(currentScreenIndex);
    }

    protected List<RecipeCreator> getAvailableRecipesCreator()
    {
        return ModRecipeCreators.getRecipeCreatorScreens(this.getMenu().getMod());
    }

    @Override
    public void render(PoseStack matrixStack, int mouseX, int mouseY, float partialTicks)
    {
        super.render(matrixStack, mouseX, mouseY, partialTicks);

        this.dataFields.forEach(field ->
        {
            if(field.visible) field.render(matrixStack, mouseX, mouseY, partialTicks);
        });

        this.buttonGrid.render(matrixStack, mouseX, mouseY, partialTicks);

        renderGui(matrixStack, mouseX, mouseY, partialTicks);

        renderTooltip(matrixStack, mouseX, mouseY);
    }

    protected abstract void renderGui(PoseStack matrixStack, int mouseX, int mouseY, float partialTicks);

    @Override
    protected void renderComponentHoverEffect(PoseStack pPoseStack, Style pStyle, int pMouseX, int pMouseY)
    {
        this.renderTooltip(pPoseStack, pMouseX, pMouseY);
        super.renderComponentHoverEffect(pPoseStack, pStyle, pMouseX, pMouseY);
    }

    protected void renderDataFieldAndTitle(int index, Component fieldTitle, PoseStack matrixStack, int mouseX, int mouseY, float partialTicks)
    {
        this.dataFields.get(index).render(matrixStack, mouseX, mouseY, partialTicks);
        renderDataFieldTitle(index, fieldTitle, matrixStack);
    }

    protected void renderDataFieldTitle(int index, Component fieldTitle, PoseStack matrixStack)
    {
        matrixStack.pushPose();
        float scale = 1F;
        matrixStack.scale(scale, scale, scale);
        Screen.drawString(matrixStack, font, fieldTitle.copy().withStyle(ChatFormatting.ITALIC), (int) (dataFields.get(index).x / scale), (int) ((dataFields.get(index).y - font.lineHeight * scale - 1) / scale), 0xFF88AEC1);
        matrixStack.popPose();
    }

    protected NumberDataFieldWidget getDataField(int index)
    {
        return this.dataFields.get(index);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers)
    {
        this.dataFields.forEach(field -> field.keyPressed(keyCode, scanCode, modifiers));
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers)
    {
        this.dataFields.forEach(field -> field.charTyped(codePoint, modifiers));
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        this.dataFields.forEach(field -> field.mouseClicked(mouseX, mouseY, button));
        if(!this.buttonGrid.isMouseOver(mouseX, mouseY)) this.buttonGrid.setVisible(false);
        else this.buttonGrid.onMouseClicked(mouseX, mouseY);
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    protected void renderBg(PoseStack matrixStack, float partialTicks, int x, int y)
    {
        this.fillGradient(matrixStack, 0, 0, this.width, this.height, -1072689136, -804253680);
        ClientUtils.color4f(1.0F, 1.0F, 1.0F, 1.0F);
        ClientUtils.bindTexture(getCurrentRecipe().getGuiTexture());
        blit(matrixStack, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.guiTextureSize, this.guiTextureSize);
        renderBackground(matrixStack);
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(new net.minecraftforge.client.event.ScreenEvent.BackgroundDrawnEvent(this, matrixStack));
    }

    @Override
    protected void renderTooltip(PoseStack poseStack, int mouseX, int mouseY)
    {
        super.renderTooltip(poseStack, mouseX, mouseY);
        this.dataFields.forEach(field -> field.renderToolTip(poseStack, mouseX, mouseY));
        this.recipeTypeButton.renderToolTip(poseStack, mouseX, mouseY);
        if(this.buttonGrid.isVisible()) this.buttonGrid.getButtons().forEach(button -> button.renderToolTip(poseStack, mouseX, mouseY));
    }

    @Override
    protected void renderLabels(PoseStack matrixStack, int pMouseX, int pMouseY)
    {
        drawCenteredString(matrixStack, ClientUtils.getFontRenderer(), References.getTranslate("screen." + this.getMenu().getMod().getModId() + "_recipe_creator." + getCurrentRecipe().getRecipeTypeLocation().getPath() + ".title"), this.imageWidth / 2, -15, 0xFFFFFF);
        if(Screen.hasShiftDown() || Screen.hasControlDown())
            drawString(matrixStack, this.font, References.getTranslate("screen.crafting.info.msg").getString(), getMessagePosX(), this.imageHeight + (isVanillaScreen && SupportedMods.isKubeJSLoaded() ? 15 : 0), 0x707370);
    }

    protected int getMessagePosX()
    {
        return 0;
    }

    protected void renderSideTitles(PoseStack matrixStack)
    {
        // Render Labels
        MutableComponent inputLabel = References.getTranslate("screen.recipe_creator.label.input");
        Component ouputLabel = References.getTranslate("screen.recipe_creator.label.output");
        Screen.drawString(matrixStack, this.font, inputLabel, this.imageWidth / 4 - font.width(inputLabel.getString()) / 2, 8, 0xFFFFFFFF);
        Screen.drawString(matrixStack, this.font, ouputLabel, this.imageWidth / 4 * 3 - font.width(ouputLabel.getString()) / 2, 8, 0xFFFFFFFF);
    }

    /**
     * @param index       the index of the slot IN the available recipe slots
     * @param name        name to render
     * @param matrixStack the matrix stack
     */
    protected void renderSlotTitle(int index, Component name, PoseStack matrixStack)
    {
        SimpleSlotItemHandler slot = getCurrentSlot(index);
        Screen.drawCenteredString(matrixStack, font, name.copy().withStyle(ChatFormatting.DARK_PURPLE), this.leftPos + slot.x + 8, this.topPos + slot.y - font.lineHeight - 1, 0xFFFFFFFF);
    }

    /**
     * @param index the index of the slot IN the available recipe slots
     * @return the slot at the given index
     */
    protected SimpleSlotItemHandler getCurrentSlot(int index)
    {
        return (SimpleSlotItemHandler) PositionnedSlot.getSlotsFor(getCurrentRecipe().getSlots(), this.getMenu().slots).get(index);
    }

    private boolean hasNext()
    {
        return currentScreenIndex < getAvailableRecipesCreator().size() - 1;
    }

    private void nextPage()
    {
        if(!hasNext()) return;

        this.currentScreenIndex++;
        updateData();
        updateScreen();
    }

    private boolean hasPrevious()
    {
        return currentScreenIndex > 0;
    }

    private void previousPage()
    {
        if(!hasPrevious()) return;

        this.currentScreenIndex--;
        updateData();
        updateScreen();
    }

    protected void addNumberField(int x, int y, int width, Number defaultValue, int count)
    {
        for(int i = 0; i < count; i++)
        {
            NumberDataFieldWidget numberDataFieldWidget = new NumberDataFieldWidget(x, y, width, 10, defaultValue, defaultValue instanceof Double);
            numberDataFieldWidget.setValue(String.valueOf(defaultValue));
            this.dataFields.add(numberDataFieldWidget);
        }
    }

    private void updateData()
    {
        updateClientData();
        updateServerData();
    }

    private void updateClientData()
    {
        this.getMenu().getTile().setScreenIndex(this.currentScreenIndex);
        this.getMenu().getTile().setCurrentRecipeType(getCurrentRecipe().getRecipeTypeLocation());
    }

    /**
     * Send packets to the server to update the tile data, sent when screen change and when the screen is closed<br>
     * Override {@link #updateExtraServerData()} to send extra data
     */
    private void updateServerData()
    {
        InitPackets.NetworkHelper.sendToServer(new UpdateRecipeCreatorTileDataServerPacket("screen_index", this.getMenu().getTile().getBlockPos(), InitPackets.PacketDataType.INT, this.currentScreenIndex));
        InitPackets.NetworkHelper.sendToServer(new UpdateRecipeCreatorTileDataServerPacket("recipe_type", this.getMenu().getTile().getBlockPos(), InitPackets.PacketDataType.STRING, getCurrentRecipe().getRecipeTypeLocation().toString()));
        InitPackets.NetworkHelper.sendToServer(new UpdateRecipeCreatorTileDataServerPacket("fields", this.getMenu().getTile().getBlockPos(), InitPackets.PacketDataType.DOUBLE_ARRAY, getFields()));
        if(isVanillaScreen) InitPackets.NetworkHelper.sendToServer(new UpdateRecipeCreatorTileDataServerPacket("kubejs_recipe", this.getMenu().getTile().getBlockPos(), InitPackets.PacketDataType.BOOLEAN, this.isKubeJSRecipeButton.selected()));
        updateExtraServerData();
    }

    /**
     * Called after {@link #updateServerData()} to update extra data on the server
     */
    protected void updateExtraServerData()
    {
    }

    protected void updateSlots()
    {
        this.getMenu().activeSlots(false);
        this.getCurrentRecipe().getSlots().forEach(ds -> this.getMenu().slots.stream().filter(s -> s.getSlotIndex() == ds.getIndex() && s instanceof SimpleSlotItemHandler).findFirst().ifPresent(slot -> ((SimpleSlotItemHandler) slot).setActive(true)));
    }

    @Override
    public void onClose()
    {
        super.onClose();

        updateServerData();
    }
}