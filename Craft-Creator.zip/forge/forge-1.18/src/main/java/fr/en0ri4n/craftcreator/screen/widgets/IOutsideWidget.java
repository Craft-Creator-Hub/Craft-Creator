package fr.en0ri4n.craftcreator.screen.widgets;


import net.minecraft.client.renderer.Rect2i;

public interface IOutsideWidget
{
    Rect2i getArea();
}
